export interface Order {
    id: number;
    name: string;
    email: string;
    phone: string;
    referral: string;
    service: string;
    message: string;
}
