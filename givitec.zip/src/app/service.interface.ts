export interface Service{
    id:number;
    amount:number;
    name:string;
}