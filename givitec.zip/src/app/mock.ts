export interface Mock {
    name:string;
    phone:string;
    subject1:string;
    subject2:string;
    subject3:string;
    subject4:string;
    s1:number;
    s2:number;
    s3:number;
    s4:number;
    reg_no:string;
    created_at:Date;
}
